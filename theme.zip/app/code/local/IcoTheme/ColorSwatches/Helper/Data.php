<?php

/**
 * @copyright   Copyright (C) 2015 icotheme.com. All Rights Reserved.
 */
class IcoTheme_ColorSwatches_Helper_Data extends Mage_Core_Helper_Abstract
{
    const CONFIG_PATH_BASE = 'colorswatches';
    const CONFIG_PATH_ENABLED = 'colorswatches/general/enabled';
    const CONFIG_PATH_SWATCH_ATTRIBUTES = 'colorswatches/general/swatch_attributes';
    const CONFIG_PATH_LIST_SWATCH_ATTRIBUTE = 'colorswatches/general/product_list_attribute';
    const CONFIG_PRODUCT_LIST_IMG_WIDTH = 'colorswatches/general/product_list_img_width';
    const CONFIG_PRODUCT_LIST_IMG_HEIGHT = 'colorswatches/general/product_list_img_height';
    const CONFIG_PRODUCT_DETAIL_IMG_WIDTH = 'colorswatches/product_detail_dimensions/product_detail_img_width';
    const CONFIG_PRODUCT_DETAIL_IMG_HEIGHT = 'colorswatches/product_detail_dimensions/product_detail_img_height';


    protected $_enabled = null;
    protected $_configAttributeIds = null;

    /**
     * Is the extension enabled?
     *
     * @return bool
     */
    public function isEnabled()
    {
        if (is_null($this->_enabled)) {
            $this->_enabled = (
                (bool)Mage::getStoreConfig(self::CONFIG_PATH_ENABLED)
                && Mage::helper('colorswatches/productlist')->getSwatchAttribute()
            );
        }
        return $this->_enabled;
    }

    /**
     * Return the formatted hyphenated string
     *
     * @param string $str
     * @return string
     */
    public function getHyphenatedString($str)
    {
        $result = false;
        if (function_exists('iconv')) {
            $result = @iconv('UTF-8', 'ASCII//TRANSLIT', $str); // will issue a notice on failure, we handle failure
        }

        if (!$result) {
            $result = dechex(crc32(self::normalizeKey($str)));
        }

        return preg_replace('/([^a-z0-9]+)/', '-', self::normalizeKey($result));
    }

    /**
     * Trims and lower-cases strings used as array indexes in json and for string matching in a
     * multi-byte compatible way if the mbstring module is available.
     *
     * @param $key
     * @return string
     */
    public static function normalizeKey($key)
    {
        if (function_exists('mb_strtolower')) {
            return trim(mb_strtolower($key, 'UTF-8'));
        }
        return trim(strtolower($key));
    }

    /**
     * Get list of attributes that should use swatches
     *
     * @return array
     */
    public function getSwatchAttributeIds()
    {
        if (is_null($this->_configAttributeIds)) {
            $this->_configAttributeIds = explode(',', Mage::getStoreConfig(self::CONFIG_PATH_SWATCH_ATTRIBUTES));
        }
        return $this->_configAttributeIds;
    }

    /**
     * Determine if an attribute should be a swatch
     *
     * @param int|Mage_Eav_Model_Attribute $attr
     * @return bool
     */
    public function attrIsSwatchType($attr)
    {
        if ($attr instanceof Varien_Object) {
            $attr = $attr->getId();
        }
        $configAttrs = $this->getSwatchAttributeIds();
        return in_array($attr, $configAttrs);
    }
}
