<?php

/**
 * @copyright   Copyright (C) 2015 icotheme.com. All Rights Reserved.
 */
class IcoTheme_WidgetBlocks_Block_Widget_Collection extends Mage_Catalog_Block_Product_Abstract
{

}