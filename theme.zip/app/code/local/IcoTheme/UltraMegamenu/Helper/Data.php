<?php

/**
 * @copyright   Copyright (C) 2015 icotheme.com. All Rights Reserved.
 */
class IcoTheme_UltraMegamenu_Helper_Data extends Mage_Core_Helper_Abstract
{

}
