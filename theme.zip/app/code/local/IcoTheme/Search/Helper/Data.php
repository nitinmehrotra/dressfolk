<?php
/**
 * @copyright   Copyright (C) 2015 IcoTheme.com. All Rights Reserved.
 */

class IcoTheme_Search_Helper_Data extends Mage_Core_Helper_Abstract{

}
